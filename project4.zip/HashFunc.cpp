#include "HashFunc.h"

using namespace std;

/**
 * Put information about this hash function here
 */
unsigned int HashA(const std::string& s)
{
	// TODO
	return 0;
}

/**
 * Put information about this hash function here
 */
unsigned int HashB(const std::string& s)
{
	// TODO
	return 0;
}

/**
 * Put information about this hash function here
 */
unsigned int HashC(const std::string& s)
{
	// TODO
	return 0;
}